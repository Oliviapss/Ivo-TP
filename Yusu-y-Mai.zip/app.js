
document.getElementById('searchForm').addEventListener('submit', async e => {
    e.preventDefault();
    const query = document.getElementById('searchInput').value;
    const res = await fetch(`https://api.unsplash.com/search/photos?query=${query}&client_id=TU_ACCESS_KEY`);
    const data = await res.json();

    const container = document.getElementById('photosContainer');
    container.innerHTML = '';
    data.results.forEach(photo => {
        const div = document.createElement('div');
        const img = document.createElement('img');
        img.src = photo.urls.small;
        img.dataset.full = photo.urls.full;
        div.appendChild(img);

        const btn = document.createElement('button');
        btn.textContent = "Guardar";
        btn.onclick = () => {
            let saved = JSON.parse(localStorage.getItem("savedPhotos") || "[]");
            saved.push(photo.urls.full);
            localStorage.setItem("savedPhotos", JSON.stringify(saved));
            alert("Foto guardada!");
        };
        div.appendChild(btn);

        container.appendChild(div);
    });
});
